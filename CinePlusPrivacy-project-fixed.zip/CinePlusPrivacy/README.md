# CinePlus Privacy — primera versión
Aplicación Android para teléfono y Android TV, con interfaz cinematográfica.

Incluye importación M3U, alta manual de URL HTTP/HTTPS, reproducción interna mediante AndroidX Media3 y apertura externa en VLC/MX Player/otro reproductor. No integra SDK publicitarios, analítica, cuentas, permisos de ubicación ni identificador publicitario.

No incluye películas, series, canales ni enlaces de terceros. Añade únicamente listas y fuentes que tengas derecho o autorización para utilizar.

## Compilación
Requiere Android Studio reciente, JDK 17 y Android SDK 35.
Abre esta carpeta en Android Studio, sincroniza Gradle y selecciona Build > Build APK(s).
APK debug: app/build/outputs/apk/debug/app-debug.apk

## Estado
Prototipo inicial. La biblioteca aún no persiste entre reinicios; faltan favoritos, edición/borrado de fuentes, cabeceras HTTP avanzadas y pruebas físicas en Android TV.
Paquete: com.cineplus.privacy
