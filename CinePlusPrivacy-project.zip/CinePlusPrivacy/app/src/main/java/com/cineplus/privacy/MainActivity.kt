package com.cineplus.privacy

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.focus.focusable
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader

private val Bg=Color(0xFF090D16)
private val Card=Color(0xFF151D2B)
private val Gold=Color(0xFFE6B85C)
private val Muted=Color(0xFF9AA8BC)
data class SourceItem(val name:String,val url:String,val group:String="Mi lista")

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{ CineApp() }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CineApp(){
 val ctx=androidx.compose.ui.platform.LocalContext.current
 var query by remember{mutableStateOf("")}
 var items by remember{mutableStateOf(listOf<SourceItem>())}
 var notice by remember{mutableStateOf("Importa una lista M3U o añade una URL autorizada.")}
 var addDialog by remember{mutableStateOf(false)}
 var name by remember{mutableStateOf("")}
 var url by remember{mutableStateOf("")}
 var selected by remember{mutableStateOf<SourceItem?>(null)}
 val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){ uri->
  if(uri!=null) try{
   val data=ctx.contentResolver.openInputStream(uri)?.use{BufferedReader(InputStreamReader(it)).readText()}.orEmpty()
   val parsed=parseM3u(data);items=items+parsed;notice="Importados ${parsed.size} elementos."
  }catch(e:Exception){notice="No se pudo leer la lista: ${e.message}"}
 }
 MaterialTheme(colorScheme=darkColorScheme(primary=Gold,background=Bg,surface=Card,onBackground=Color.White,onSurface=Color.White)){
  Scaffold(containerColor=Bg,topBar={TopAppBar(title={Column{Text("CINEPLUS",fontWeight=FontWeight.Black,letterSpacing=2.sp);Text("PRIVACY  •  TU CONTENIDO, TUS REGLAS",fontSize=9.sp,color=Muted)}},actions={Icon(Icons.Default.Shield,null,tint=Gold,modifier=Modifier.padding(end=18.dp))},colors=TopAppBarDefaults.topAppBarColors(containerColor=Bg))},
   floatingActionButton={FloatingActionButton(onClick={addDialog=true},containerColor=Gold,contentColor=Bg){Icon(Icons.Default.Add,null)}}){ pad->
   Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=16.dp)){
    Spacer(Modifier.height(10.dp))
    Column(Modifier.fillMaxWidth().background(Color(0xFF202D42),RoundedCornerShape(20.dp)).padding(18.dp)){
     Text("TU CINE.",color=Gold,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp)
     Text("Sin ruido.\\nSin rastreadores añadidos.",fontSize=25.sp,lineHeight=29.sp,fontWeight=FontWeight.ExtraBold)
     Text("Reproduce fuentes que tú agregues.",color=Muted,fontSize=12.sp)
    }
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),placeholder={Text("Buscar en tus listas…")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
    Spacer(Modifier.height(8.dp))
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     Button(onClick={picker.launch(arrayOf("*/*"))}){Text("Importar M3U")}
     OutlinedButton(onClick={addDialog=true}){Text("Añadir URL")}
    }
    Text(notice,color=Muted,fontSize=11.sp,modifier=Modifier.padding(vertical=8.dp))
    Text("MI BIBLIOTECA  •  ${items.size}",color=Gold,fontSize=11.sp,fontWeight=FontWeight.Bold)
    val filtered=items.filter{it.name.contains(query,true)||it.group.contains(query,true)}
    if(filtered.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){Text("Tu biblioteca está lista.\\nImporta una lista M3U o añade una URL.",color=Muted)}
    else LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)){items(filtered){item->
     Row(Modifier.fillMaxWidth().background(Card,RoundedCornerShape(14.dp)).clickable{selected=item}.focusable().padding(14.dp),verticalAlignment=Alignment.CenterVertically){
      Box(Modifier.size(42.dp).background(Color(0xFF27354A),RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.PlayArrow,null,tint=Gold)}
      Column(Modifier.weight(1f).padding(start=12.dp)){Text(item.name,fontWeight=FontWeight.SemiBold);Text(item.group,color=Muted,fontSize=11.sp)}
      Text("VER",color=Gold,fontSize=10.sp,fontWeight=FontWeight.Bold)
     }
    }}
   }
  }
  if(addDialog) AlertDialog(onDismissRequest={addDialog=false},title={Text("Añadir fuente")},text={Column{OutlinedTextField(name,{name=it},label={Text("Nombre")});OutlinedTextField(url,{url=it},label={Text("URL HTTPS o HTTP")});Text("Añade solamente fuentes que tengas autorización para usar.",fontSize=11.sp,color=Muted)}},confirmButton={TextButton(onClick={
   val u=Uri.parse(url.trim());if(u.scheme in listOf("http","https")&&u.host!=null){items=items+SourceItem(name.ifBlank{u.host!!},url.trim());notice="Fuente añadida.";name="";url="";addDialog=false}else notice="URL no válida."
  }){Text("Guardar")}},dismissButton={TextButton(onClick={addDialog=false}){Text("Cancelar")}})
  selected?.let{item->PlayerDialog(item,{selected=null}){pkg->
   val intent=Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(item.url),"video/*").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
   if(pkg!=null)intent.setPackage(pkg)
   try{ctx.startActivity(intent)}catch(_:Exception){notice="No se encontró el reproductor seleccionado."}
  }}
 }
}

@Composable
fun PlayerDialog(item:SourceItem,onClose:()->Unit,onExternal:(String?)->Unit){
 val ctx=androidx.compose.ui.platform.LocalContext.current
 val exoPlayer=remember(item.url){ExoPlayer.Builder(ctx).build().apply{setMediaItem(MediaItem.fromUri(item.url));prepare();playWhenReady=true}}
 DisposableEffect(exoPlayer){onDispose{exoPlayer.release()}}
 AlertDialog(onDismissRequest=onClose,title={Text(item.name)},text={Column{
  AndroidView(factory={PlayerView(it).apply{player=exoPlayer;useController=true}},modifier=Modifier.fillMaxWidth().height(200.dp))
  Text("Si el formato no funciona, prueba otro reproductor.",color=Muted,fontSize=11.sp)
  Row{TextButton(onClick={onExternal("org.videolan.vlc")}){Text("VLC")};TextButton(onClick={onExternal("com.mxtech.videoplayer.ad")}){Text("MX Player")};TextButton(onClick={onExternal(null)}){Text("Otro")}}
 }},confirmButton={TextButton(onClick=onClose){Text("Cerrar")}})
}

fun parseM3u(text:String):List<SourceItem>{
 val out=mutableListOf<SourceItem>();var title="Canal";var group="Mi lista"
 text.lineSequence().forEach{raw->val line=raw.trim();when{
  line.startsWith("#EXTINF",true)->{title=line.substringAfterLast(",").trim().ifBlank{"Canal"};group=Regex("""group-title="([^"]+)"""").find(line)?.groupValues?.get(1)?: "Mi lista"}
  line.isNotBlank()&&!line.startsWith("#")-> {val u=Uri.parse(line);if(u.scheme in listOf("http","https")&&u.host!=null){out+=SourceItem(title,line,group);title="Canal";group="Mi lista"}}
 }}
 return out
}
